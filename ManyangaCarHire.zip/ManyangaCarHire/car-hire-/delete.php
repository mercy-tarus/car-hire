<?php
 include ("server.php");

 if(isset($_REQUEST["car"]))
 {
     $query=mysqli_query($conn,"DELETE FROM cars WHERE id='".$_REQUEST["car"]."'");
     if($query)
     {
         echo "<script>alert('Delete Successful!');location.href='addedcars.php';</script>";
     }
 }
?>