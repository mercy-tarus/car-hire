<?php
include("server.php");
if(!isset($_SESSION["NAME"]))
{
    echo "<script>location.href='login.php';</script>";
}
?>