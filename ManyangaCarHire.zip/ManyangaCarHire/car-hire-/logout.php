<?php
session_start();
unset($_SESSION["ID"]);
unset($_SESSION["NAME"]);
unset($_SESSION["USERNAME"]);
unset($_SESSION["ADDRESS"]);
unset($_SESSION["GENDER"]);
unset($_SESSION["EMAIL"]);
unset($_SESSION["PHONE"]);
unset($_SESSION["USERTYPE"]);
unset($_SESSION["IDNO"]);

echo "<script>alert('You are Logged out!!');location.href='login.php';</script>";
?>