<?php
include("server.php");
if(isset($_SESSION["NAME"]))
{
    echo "<script>location.href='logout.php';</script>";
}
?>
<html>



<head>

    <!--HEADER CSS-->
    <style>
        #header
        {
            background:url(ekeza.png);
            background-size:contain,cover;
            background-repeat:no-repeat;
            height:400px;
        }

        #navbar
        {
            background-color:green;
            border-radius:5px;
            padding:15px;
        }
        a
        {
            text-decoration:none;
            color:white;
        }
        #user
        {
            background-color:aqua;
            width:40%;
            border-radius:15px;
            height:250px;
            border:1px solid red;
            box-shadow: 5px 5px;
        }
        #inptype
        {
            border-radius:5px;
            border:1px solid tomato;
            padding:5px;
        }
        a:hover
        {
            background-color:black;
            padding:15px;
        }
        #forgot_pswrd
        {
            color:black;
        }
        #forgot_pswrd:hover
        {
            color:white;
            border-radius:5px;
        }
        #register
        {
            background-color:darkkhaki;
            width:40%;
            border-radius:10px;
            height:520px;
        }
        #side:hover
        {
            background-color:orange;
            color:white;
        }
        #deposit
        {
            width:60%;
            height:200px;
            border-radius:10px;
            border:1px solid tomato;
            background-color:antiquewhite;
        }
        #transfer
        {
            width:60%;
            height:250px;
            border-radius:60px;
            border:1px solid brown;
            background-color:cyan;
        }
        #withdraw
        {
            width:60%;
            height:200px;
            border-radius:60px;
            border:1px solid blue;
            background-color:gainsboro;
        }
        #edit
        {
            color:white;
            background-color:darkgreen;
            padding:3px;
            border-radius:3px;
        }
        #edit:hover
        {
            background-color:black;
            padding:3px;
            border-radius:3px;
            color:white;
        }
        .check:hover
        {
            background-color:white;
        }
        .savingsaccount
        {
            color:black;
        }
        .savingsaccount:hover
        {
            background-color:white;
        }

    </style>




    <title>ManyangaCarHire- Register
    </title>
</head>


<body style="background-image: url('reg.png');background-size: 100% 100%;background-repeat: no-repeat;">
<center>



    <center><h1 style="font-weight: bold;color: blue;font-family: 'BankGothic Md BT';font-size:51px;padding: 10px;">ManyangaCars</h1></center>
<div id="register">
    <marquee><h2>Create your online account here</h2></marquee>
    <fieldset>
        <legend>Enter your personal details</legend>
        <form action="register.php" method="post" enctype="multipart/form-data">
            <table width="80%" border="0" cellspacing="0">
                <tr>
                    <td>Full name:</td>
                    <td><input type="text" name="name" required placeholder="Full Name..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Gender:</td>
                    <td><input type="radio" name="gender" value="male" required id="inptype">Male | <input type="radio" name="gender" value="female" required id="inptype">Female</td>
                </tr>
                <tr>
                    <td>ID number:</td>
                    <td><input type="text" name="id_number" required placeholder="ID number..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td><textarea name="address" required placeholder="Address..." id="inptype"></textarea></td>
                </tr>
                <tr>
                    <td>E-mail:</td>
                    <td><input type="email" name="email" required placeholder="E-mail..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Mobile no:</td>
                    <td><input type="text" name="phone" required placeholder="Mobile number..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" placeholder="Username..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="pas1" required placeholder="Password..." id="inptype"></td>
                </tr>
                <tr>
                    <td>Confirm password:</td>
                    <td><input type="password" name="pas2" required id="inptype"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="reg" value="Register" id="inptype"></td>
                </tr>
            </table>
        </form>
        <p>Already Registered? <a href="login.php" style="text-decoration: none;color:blue;">Login Here!</a></p>
    </fieldset>
</div>
</center>
</body>