<?php
 include("server.php");
   $query= mysqli_query($conn,"SELECT * FROM cars WHERE model='".$_REQUEST["a"]."'");
   $row=mysqli_fetch_array($query);
   $in_p=$row["price"];
   $total= $in_p * $_REQUEST["q"];
 if($_REQUEST!==0)
 {
   echo "Ksh : ".$total;
 }
 else
 {
     echo "Ksh : 0";
 }

?>