<?php
include("server.php");
if(!isset($_SESSION["NAME"]))
{
    echo "<script>location.href='login.php';</script>";
}
?>
<html>



<head>

    <!--HEADER CSS-->
    <style>
        #header
        {
            background:url(ekeza.png);
            background-size:contain,cover;
            background-repeat:no-repeat;
            height:400px;
        }

        #navbar
        {
            background-color:green;
            border-radius:5px;
            padding:15px;
        }
        a
        {
            text-decoration:none;
            color:white;
        }
        #user
        {
            background-color:aqua;
            width:40%;
            border-radius:15px;
            height:250px;
            border:1px solid red;
            box-shadow: 5px 5px;
        }
        #inptype
        {
            border-radius:5px;
            border:1px solid tomato;
            padding:5px;
        }
        a:hover
        {
            background-color:black;
            padding:15px;
        }
        #forgot_pswrd
        {
            color:black;
        }
        #forgot_pswrd:hover
        {
            color:white;
            border-radius:5px;
        }
        #register
        {
            background-color:darkkhaki;
            width:40%;
            border-radius:10px;
            height:490px;
        }
        #side:hover
        {
            background-color:orange;
            color:white;
        }
        #deposit
        {
            width:60%;
            height:200px;
            border-radius:10px;
            border:1px solid tomato;
            background-color:antiquewhite;
        }
        #transfer
        {
            width:60%;
            height:250px;
            border-radius:60px;
            border:1px solid brown;
            background-color:cyan;
        }
        #withdraw
        {
            width:60%;
            height:200px;
            border-radius:60px;
            border:1px solid blue;
            background-color:gainsboro;
        }
        #edit
        {
            color:white;
            background-color:darkgreen;
            padding:3px;
            border-radius:3px;
        }
        #edit:hover
        {
            background-color:black;
            padding:3px;
            border-radius:3px;
            color:white;
        }
        .check:hover
        {
            background-color:white;
        }
        .savingsaccount
        {
            color:black;
        }
        .savingsaccount:hover
        {
            background-color:white;
        }

    </style>



    <!--EKEZA BANK PAGES TITLES-->
    <title>ManyangaCarHire- Home
    </title>
</head>


<body>
<center>




    <!--NAVIGATION BAR-->

    <div id="header">
        <center><h1 style="font-weight: bold;color: blue;font-family: 'BankGothic Md BT';font-size:51px;padding: 20px;">ManyangaCars</h1></center><hr>
        <center><h2>Welcome to <?php if($_SESSION["USERTYPE"]=="admin") { ?>ADMIN <?php } else { ?>USER <?php } ?>PANEL</h2></center>
        <div id="navbar">
            <a href="home.php">Home</a> <?php if($_SESSION["USERTYPE"]=="admin") { ?> |
                <a href="addcar.php">Add Car</a> | <a href="addedcars.php">My Cars</a> <?php } else { ?> | <a href="cars.php">Cars</a> | <a href="search.php">Search</a> | <a href="hiredcars.php">Hired Cars</a> | <a href="contact.php">Find us</a><?php } ?>
            <a href="logout.php" style="float:right;">Logout</a>
        </div>
        <br><br>
       <p style="text-align:left;width:100%;font-weight: bold;"><?php echo $_SESSION["NAME"]."  [ ID Number : ".$_SESSION["IDNO"]." ]"; ?></p><hr>
    </div>
    <p>ManyangaCars is a car hire company that gives customers a chance to hire a car of their choice for a certain period of time for a favourable fee.</p>
    <br>
    <p style="padding: 50px;color:blue;">All rights reserved &copy <?php echo date("Y"); ?>. ManyangaCars</p>
</center>
</body>