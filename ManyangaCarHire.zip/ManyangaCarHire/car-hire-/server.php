<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "manyanga";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


//REGISTER USER
if(isset($_POST["reg"]))
{
    $full_name = mysqli_real_escape_string($conn, $_POST["name"]);
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $gender = mysqli_real_escape_string($conn,$_POST["gender"]);
    $address =mysqli_real_escape_string($conn, $_POST["address"]);
    $email =mysqli_real_escape_string($conn, $_POST["email"]);
    $phone_number =mysqli_real_escape_string($conn, $_POST["phone"]);
    $id_no =mysqli_real_escape_string($conn, $_POST["id_number"]);
    $password = mysqli_real_escape_string($conn,md5($_POST["pas1"]));
    $con_password =mysqli_real_escape_string($conn, md5($_POST["pas2"]));

    $Check_USR = mysqli_query($conn,"SELECT * FROM users WHERE username='$username' and email='$email'");
    $USR=mysqli_num_rows($Check_USR);
    if($USR ==0)
    {
        //submit ation here
        if($password ==$con_password)
        {
            //submit action
            $query2 = mysqli_query($conn,"INSERT INTO users VALUES(0,'$full_name','$gender','$id_no','$address','$email','$phone_number','$username','user','$password')")
            or mysqli_error("Error in query!!");
            echo "<script>alert('Registration Successful!!');location.href='login.php';</script>";
        }
        else
        {
            echo "<script>alert('Password and Confirm password do not match');</script>";
        }
    }
    else
    {
        echo "<script>alert('A user with those details already exists!!');</script>";
    }
}

//LOGIN USER
if(isset($_POST["login"]))
{
    $username=mysqli_real_escape_string($conn,$_POST["username"]);
    $pass =mysqli_real_escape_string($conn,md5($_POST["pass"]));

    $query = mysqli_query($conn,"SELECT * FROM users WHERE username='$username' and password='$pass'");

    $result = mysqli_num_rows($query);
    if($result>0)
    {
        $row = mysqli_fetch_assoc($query);
        $_SESSION["ID"] = $row["id"];
        $_SESSION["NAME"] =$row["name"];
        $_SESSION["USERNAME"] =$row["username"];
        $_SESSION["ADDRESS"] =$row["address"];
        $_SESSION["GENDER"]=$row["gender"];
        $_SESSION["IDNO"]=$row["id_no"];
        $_SESSION["EMAIL"]=$row["email"];
        $_SESSION["PHONE"]=$row["phone"];
        $_SESSION["USERTYPE"]=$row["usertype"];

        echo "<script>alert('Login Successful!!');location.href='home.php';</script>";
    }
    else
    {
        echo "<script>alert('Login failed!!');</script>";
    }
}
//ADD CAR
if(isset($_POST["add"])) {
    $category = mysqli_real_escape_string($conn, $_POST["category"]);
    $model = mysqli_real_escape_string($conn, $_POST["model"]);
    $price = mysqli_real_escape_string($conn, $_POST["price"]);
    $pic = $_FILES["car_image"]["name"];


    $files_path = "cars/";
    $file_p = $files_path . $pic;
    $iFileType = strtolower(pathinfo($file_p, PATHINFO_EXTENSION));
    if ($iFileType != "png" && $iFileType != "jpg" && $iFileType != "jpeg")
    {
        echo "<script>alert('You can only Upload .png .jpg .jpeg files!');location.href='addcar.php';</script>";
    }
    else {
        $check_product = mysqli_query($conn, "SELECT * FROM cars WHERE model='$model'");
        $RE = mysqli_num_rows($check_product);
        if ($RE == 0) {
            $queryA = mysqli_query($conn, "INSERT INTO cars VALUES(0,'$category','$model','$price','$file_p')");
            if ($queryA) {
                move_uploaded_file($_FILES["car_image"]["tmp_name"], $file_p);
                echo "<script>alert('Car Added Sucessful!');location.href='addedcars.php';</script>";
            }
        }
    }
}

//HIRE CAR
if(isset($_POST["hire"]))
{
    $category = mysqli_real_escape_string($conn, $_POST["category"]);
    $model = mysqli_real_escape_string($conn, $_POST["model"]);
    $period = mysqli_real_escape_string($conn, $_POST["period"]);
    $p = mysqli_real_escape_string($conn, $_POST["price"]);
    $price = $period * $p;

    $payment = mysqli_real_escape_string($conn, $_POST["payment"]);

    $name = $_SESSION["NAME"];
    $check = mysqli_query($conn,"SELECT * FROM hired_cars WHERE customer_name='$name' and model='$model' and status='pending'");
    $result=mysqli_num_rows($check);
    if($result==0)
    {
        $queryA = mysqli_query($conn, "INSERT INTO hired_cars VALUES(0,'$name','$category','$model','$period','$price','$payment','Hired')");
        if ($queryA) {
            
            echo "<script>alert('Hire Successful!');location.href='hiredcars.php';</script>";
        }
    }
    else
    {
        echo "<script>alert('You have already Booked this car and status is pending');</script>";
    }

}

?>