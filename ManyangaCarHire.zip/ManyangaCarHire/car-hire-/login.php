<?php
include("server.php");
if(isset($_SESSION["NAME"]))
{
    echo "<script>location.href='logout.php';</script>";
}
?>
<html>



<head>

    <!--HEADER CSS-->
    <style>
        #header
        {
            background:url(ekeza.png);
            background-size:contain,cover;
            background-repeat:no-repeat;
            height:400px;
        }

        #navbar
        {
            background-color:green;
            border-radius:5px;
            padding:15px;
        }
        a
        {
            text-decoration:none;
            color:white;
        }
        #user
        {
            background-color:aqua;
            width:40%;
            border-radius:15px;
            height:250px;
            border:1px solid red;
            box-shadow: 5px 5px;
        }
        #inptype
        {
            border-radius:5px;
            border:1px solid tomato;
            padding:5px;
        }
        a:hover
        {
            background-color:black;
            padding:15px;
        }
        #forgot_pswrd
        {
            color:black;
        }
        #forgot_pswrd:hover
        {
            color:white;
            border-radius:5px;
        }
        #register
        {
            background-color:darkkhaki;
            width:40%;
            border-radius:10px;
            height:490px;
        }
        #side:hover
        {
            background-color:orange;
            color:white;
        }
        #deposit
        {
            width:60%;
            height:200px;
            border-radius:10px;
            border:1px solid tomato;
            background-color:antiquewhite;
        }
        #transfer
        {
            width:60%;
            height:250px;
            border-radius:60px;
            border:1px solid brown;
            background-color:cyan;
        }
        #withdraw
        {
            width:60%;
            height:200px;
            border-radius:60px;
            border:1px solid blue;
            background-color:gainsboro;
        }
        #edit
        {
            color:white;
            background-color:darkgreen;
            padding:3px;
            border-radius:3px;
        }
        #edit:hover
        {
            background-color:black;
            padding:3px;
            border-radius:3px;
            color:white;
        }
        .check:hover
        {
            background-color:white;
        }
        .savingsaccount
        {
            color:black;
        }
        .savingsaccount:hover
        {
            background-color:white;
        }

    </style>




    <title>ManyangaCarHire- Login
    </title>
</head>


<body style="background-color: honeydew;">
<center>







        <br><br><br>
    <center><h1 style="font-weight: bold;color: blue;font-family: 'BankGothic Md BT';font-size:51px;padding: 20px;">ManyangaCars</h1></center>
    <br>


        <div id="user">
    <marquee style="border-radius:12px 12px 0px 0px;background-color:red;color:white;padding:15px;"><b>User Account Login</b></marquee>
    <br><br><br>
    <form action="login.php" method="post" enctype="multipart/form-data">
        <table width="80%" border="0" cellspacing="0">
            <tr>
                <td>Username:</td>
                <td><input type="text" name="username" required placeholder="Username..." id="inptype"></td>
            </tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" name="pass" required placeholder="Password..." id="inptype"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" name="login" value="Login" id="inptype"></td>
            </tr>
        </table>
        <p><a href="register.php" id="forgot_pswrd">Not Registered? Click Here</a></p>
    </form>
</div>
</center>
</body>