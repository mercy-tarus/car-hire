<?php

session_start();
include "includes/config.php";
$page =$_REQUEST["pg"];

if(!isset($_SESSION["ID"]) and $page!=="hm" and $page!=="ab" and $page!=="rg" and $page!=="lg1" and $page!=="admlg")
{
    echo "<script>location.href='user_login.php?pg=lg1';</script>";

}
?>
<html>



<head>

    <!--HEADER CSS-->
    <style>
        #header
        {
            background:url(ekeza.png);
            background-size:contain,cover;
            background-repeat:no-repeat;
            height:400px;
        }

        #navbar
        {
            background-color:green;
            border-radius:5px;
            padding:15px;
        }
        a
        {
            text-decoration:none;
            color:white;
        }
        #user
        {
            background-color:aqua;
            width:40%;
            border-radius:15px;
            height:250px;
            border:1px solid red;
            box-shadow: 5px 5px;
        }
        #inptype
        {
            border-radius:5px;
            border:1px solid tomato;
            padding:5px;
        }
        a:hover
        {
            background-color:black;
            padding:15px;
        }
        #forgot_pswrd
        {
            color:black;
        }
        #forgot_pswrd:hover
        {
            color:white;
            border-radius:5px;
        }
        #register
        {
            background-color:darkkhaki;
            width:40%;
            border-radius:10px;
            height:490px;
        }
        #side:hover
        {
            background-color:orange;
            color:white;
        }
        #deposit
        {
            width:60%;
            height:200px;
            border-radius:10px;
            border:1px solid tomato;
            background-color:antiquewhite;
        }
        #transfer
        {
            width:60%;
            height:250px;
            border-radius:60px;
            border:1px solid brown;
            background-color:cyan;
        }
        #withdraw
        {
            width:60%;
            height:200px;
            border-radius:60px;
            border:1px solid blue;
            background-color:gainsboro;
        }
        #edit
        {
            color:white;
            background-color:darkgreen;
            padding:3px;
            border-radius:3px;
        }
        #edit:hover
        {
            background-color:black;
            padding:3px;
            border-radius:3px;
            color:white;
        }
        .check:hover
        {
            background-color:white;
        }
        .savingsaccount
        {
            color:black;
        }
        .savingsaccount:hover
        {
            background-color:white;
        }

    </style>



    <!--EKEZA BANK PAGES TITLES-->
    <title>Ekeza-
        <?php
        if($page=="hm"){echo "Home";}
        if($page=="ab"){echo "About";}
        if($page=="rg"){echo "Create Account";}
        if($page=="lg1"){echo "Login";}
        if($page=="lg"){echo "Logout";}
        if($page=="ln"){echo "Apply Loan";}
        if($page=="sv"){echo "Save";}
        if($page=="admlg"){echo "Admin Login";}
        if($page=="tr"){echo "Transfer Money";}
        if($page=="py"){echo "Pay bills";}
        if($page=="bl"){echo "Balance";}
        if($page=="dp"){echo "Deposit From M-pesa";}
        ?>
    </title>
</head>


<body>
<center>




    <!--NAVIGATION BAR-->

    <div id="header">
        <br><br><br><br><br>
        <br><br><br><br><br>
        <div id="navbar">
            <a href="../user/index.php?pg=hm">Home</a> |
            <?php
            if(!isset($_SESSION["ID"]))
            {
                ?>

                <a href="about.php ?pg=ab">About</a> | <a href="register.php ?pg=rg">Create Account</a> | <a href="user_login.php ?pg=lg1">User Login</a><a href="../admin/admin_login.php ?pg=admlg" style="float:right;">Admin Login</a>
                <?php
            }
            else
            {
                ?>
                <a href="profile.php?pg=prof">Profile</a>
                | <a href="deposit.php?pg=dp">Deposit from M-pesa</a> | <a href="withdraw.php?pg=wd">Withdraw to M-pesa</a> | <a href="transfer.php ?pg=tr">Transfer Money</a> | <a href="balance.php?pg=bl">Check Balance</a>
                | <a href="loan.php ?pg=ln">Apply Loan</a> | <a href="save.php ?pg=sv">Save</a> <a href="logout_user.php" style="float:right;">Logout</a>
                <?php
            }
            ?>
        </div>
        <br><br>

